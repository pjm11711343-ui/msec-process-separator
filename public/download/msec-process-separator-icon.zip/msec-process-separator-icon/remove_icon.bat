@echo off
chcp 65001 >nul
title 공정분리 자동화 - 아이콘 제거
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1"
pause
