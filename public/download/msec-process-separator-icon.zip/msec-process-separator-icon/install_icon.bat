@echo off
chcp 65001 >nul
title 공정분리 자동화 - 아이콘 설치
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
pause
