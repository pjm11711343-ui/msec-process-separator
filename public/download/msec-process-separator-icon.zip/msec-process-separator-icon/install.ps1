﻿# 명신기공 기계설비 공정분리 자동화 툴 - 바탕화면/시작메뉴 아이콘 설치
$ErrorActionPreference = 'Stop'
$AppName = '공정분리 자동화'
$Url = 'https://msec-process-separator.vercel.app/?source=app'

$dir = Join-Path $env:LOCALAPPDATA 'MSEC\ProcessSeparator'
New-Item -ItemType Directory -Force -Path $dir | Out-Null
$ico = Join-Path $dir 'app.ico'
Copy-Item -Path (Join-Path $PSScriptRoot 'app.ico') -Destination $ico -Force

# 브라우저 찾기 (크롬 우선, 없으면 엣지) - 주소창 없는 앱 창으로 실행
$pf86 = ${env:ProgramFiles(x86)}
if (-not $pf86) { $pf86 = $env:ProgramFiles }
$candidates = @(
  (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
  (Join-Path $pf86 'Google\Chrome\Application\chrome.exe'),
  (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe'),
  (Join-Path $pf86 'Microsoft\Edge\Application\msedge.exe'),
  (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe')
)
$browser = $candidates | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1

$targets = @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))
$shell = New-Object -ComObject WScript.Shell

foreach ($folder in $targets) {
  if (-not $folder) { continue }
  if ($browser) {
    $lnk = $shell.CreateShortcut((Join-Path $folder "$AppName.lnk"))
    $lnk.TargetPath = $browser
    $lnk.Arguments = "--app=$Url"
    $lnk.IconLocation = "$ico,0"
    $lnk.WorkingDirectory = $dir
    $lnk.Description = '명신기공 기계설비 공정분리 자동화 툴'
    $lnk.Save()
  } else {
    $content = "[InternetShortcut]`r`nURL=$Url`r`nIconFile=$ico`r`nIconIndex=0`r`n"
    Set-Content -Path (Join-Path $folder "$AppName.url") -Value $content -Encoding Default
  }
}

Write-Host ''
Write-Host '  설치 완료: 바탕화면과 시작 메뉴에 [공정분리 자동화] 아이콘이 만들어졌습니다.' -ForegroundColor Green
if ($browser) { Write-Host "  실행 브라우저: $browser" } else { Write-Host '  크롬/엣지를 찾지 못해 기본 브라우저로 열리는 아이콘을 만들었습니다.' -ForegroundColor Yellow }
Write-Host ''
