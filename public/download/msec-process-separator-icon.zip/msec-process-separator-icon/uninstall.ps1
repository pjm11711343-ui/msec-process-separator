﻿# 공정분리 자동화 아이콘 제거
$AppName = '공정분리 자동화'
foreach ($folder in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
  foreach ($ext in @('lnk', 'url')) {
    $p = Join-Path $folder "$AppName.$ext"
    if (Test-Path $p) { Remove-Item $p -Force }
  }
}
$dir = Join-Path $env:LOCALAPPDATA 'MSEC\ProcessSeparator'
if (Test-Path $dir) { Remove-Item $dir -Recurse -Force }
Write-Host ''
Write-Host '  아이콘을 제거했습니다. (저장된 공정분리 데이터는 그대로 남아 있습니다)' -ForegroundColor Green
Write-Host ''
